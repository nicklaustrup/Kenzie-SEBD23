# ATA Week 12 Activity

# Gradle Commands
## Recursion - Countdown
Run the unit test for the Recursion Countdown activity

```bash
./gradlew recursion-countdown-test 
```

## Recursion - MagicIndex
Run the unit tests for the Recursion Magic Index activity

```bash
./gradlew recursion-magic-index-test
```

## Recursion - LinkedList
Run the unit tests for the LinkedList activity
```bash
./gradlew recursion-linkedlist-phase0
./gradlew recursion-linkedlist-sum
./gradlew recursion-linkedlist-reverse
./gradlew recursion-linkedlist-size
./gradlew recursion-linkedlist-contains
./gradlew recursion-linkedlist-max
./gradlew recursion-linkedlist-hashcode
./gradlew recursion-linkedlist-equals
```
