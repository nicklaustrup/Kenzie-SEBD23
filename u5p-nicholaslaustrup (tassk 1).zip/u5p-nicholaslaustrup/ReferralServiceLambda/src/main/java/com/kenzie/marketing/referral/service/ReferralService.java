package com.kenzie.marketing.referral.service;

import com.kenzie.marketing.referral.model.CustomerReferrals;
import com.kenzie.marketing.referral.model.LeaderboardEntry;
import com.kenzie.marketing.referral.model.Referral;
import com.kenzie.marketing.referral.model.ReferralRequest;
import com.kenzie.marketing.referral.model.ReferralResponse;
import com.kenzie.marketing.referral.service.converter.ReferralConverter;
import com.kenzie.marketing.referral.service.dao.ReferralDao;
import com.kenzie.marketing.referral.service.exceptions.InvalidDataException;
import com.kenzie.marketing.referral.service.model.ReferralRecord;

import javax.inject.Inject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.List;
import java.util.stream.Collectors;

public class ReferralService {

    private ReferralDao referralDao;
    private ExecutorService executor;

    @Inject
    public ReferralService(ReferralDao referralDao) {
        this.referralDao = referralDao;
        this.executor = Executors.newCachedThreadPool();
    }

    // Necessary for testing, do not delete
    public ReferralService(ReferralDao referralDao, ExecutorService executor) {
        this.referralDao = referralDao;
        this.executor = executor;
    }

    public List<LeaderboardEntry> getReferralLeaderboard() {
        // Task 3 Code Here
        return null;
    }

    public CustomerReferrals getCustomerReferralSummary(String customerId) {
        CustomerReferrals referrals = new CustomerReferrals();
        int firstLevelCount = 0;
        int secondLevelCount = 0;
        int thirdLevelCount = 0;


        List<ReferralRecord> referralRecordsFirst = referralDao.findUsersWithoutReferrerId();
        for (ReferralRecord referralRecord:referralRecordsFirst){
            if (referralRecord.getReferrerId().equals(customerId)){
                firstLevelCount++;
            }
            List<ReferralRecord> referralRecordsSecond = referralDao.findByReferrerId(referralRecord.getCustomerId());
            String secondReferrerId = referralRecord.getCustomerId();
            for (ReferralRecord referralRecord2:referralRecordsSecond){
                if (referralRecord2.getReferrerId().equals(secondReferrerId)){
                    secondLevelCount++;
                }
                List<ReferralRecord> referralRecordsThird = referralDao.findByReferrerId(referralRecord2.getCustomerId());
                String thirdReferrerId = referralRecord2.getCustomerId();
                for (ReferralRecord referrerRecord3:referralRecordsThird) {
                    if (referrerRecord3.getReferrerId().equals(thirdReferrerId)) {
                        thirdLevelCount++;
                    }
                }
            }
            }

        referrals.setNumFirstLevelReferrals(firstLevelCount);
        referrals.setNumSecondLevelReferrals(secondLevelCount);
        referrals.setNumThirdLevelReferrals(thirdLevelCount);
        return referrals;
    }


    public List<Referral> getDirectReferrals(String customerId) {
        List<ReferralRecord> records = referralDao.findByReferrerId(customerId);


        return records.stream()
                .map(ReferralConverter::fromRecordToReferral)
                .collect(Collectors.toList());
    }


    public ReferralResponse addReferral(ReferralRequest referral) {
        if (referral == null || referral.getCustomerId() == null || referral.getCustomerId().length() == 0) {
            throw new InvalidDataException("Request must contain a valid Customer ID");
        }
        ReferralRecord record = ReferralConverter.fromRequestToRecord(referral);
        referralDao.addReferral(record);
        return ReferralConverter.fromRecordToResponse(record);
    }

    public boolean deleteReferrals(List<String> customerIds){
        boolean allDeleted = true;

        if(customerIds == null){
            throw new InvalidDataException("Request must contain a valid list of Customer ID");
        }

        for(String customerId : customerIds){
            if(customerId == null || customerId.length() == 0){
                throw new InvalidDataException("Customer ID cannot be null or empty to delete");
            }

            ReferralRecord record = new ReferralRecord();
            record.setCustomerId(customerId);

            boolean deleted = referralDao.deleteReferral(record);

            if(!deleted){
                allDeleted = false;
            }
        }
        return allDeleted;
    }
}
