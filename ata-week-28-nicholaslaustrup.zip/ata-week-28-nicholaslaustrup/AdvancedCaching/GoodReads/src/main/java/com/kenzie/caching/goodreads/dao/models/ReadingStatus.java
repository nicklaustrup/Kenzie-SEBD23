package com.kenzie.caching.goodreads.dao.models;

public enum ReadingStatus {
    WANT_TO_READ, CURRENTLY_READING, READ;
}
