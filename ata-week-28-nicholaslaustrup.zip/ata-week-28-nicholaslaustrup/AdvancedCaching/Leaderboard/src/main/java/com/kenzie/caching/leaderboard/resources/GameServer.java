package com.kenzie.caching.leaderboard.resources;

public class GameServer {

    /**
     * Starts a game for a player to play on the game server.
     *
     * @param username - name of the player to start the game for
     */
    public void startGame(String username) {}
}
