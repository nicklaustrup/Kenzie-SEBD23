package com.kenzie.caching.leaderboard.resources;

/**
 * The result of starting a game for a player.
 */
public class StartGameResult {
}
